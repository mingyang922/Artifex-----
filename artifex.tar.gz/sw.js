/**
 * Artifex - Service Worker
 * 提供静态资源缓存和离线支持
 */

const CACHE_NAME = 'artifex-v1.3.3';
const STATIC_ASSETS = [
    '/',
    '/login.html',
    '/dashboard.html',
    '/styles/ui-kit.css',
    '/styles/dashboard.css',
    '/styles/app-shell.css',
    '/vendor/css/font-awesome.min.css',
    '/vendor/css/google-fonts.css',
    '/vendor/jszip.min.js',
];

// 安装事件 - 预缓存静态资源
self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME).then((cache) => {
            return cache.addAll(STATIC_ASSETS);
        })
    );
    self.skipWaiting();
});

// 激活事件 - 清理旧缓存
self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then((cacheNames) => {
            return Promise.all(
                cacheNames
                    .filter((name) => name !== CACHE_NAME)
                    .map((name) => caches.delete(name))
            );
        })
    );
    self.clients.claim();
});

// 请求拦截 - 缓存优先策略
self.addEventListener('fetch', (event) => {
    const { request } = event;
    const url = new URL(request.url);

    // 跳过 API 请求（需要实时数据）
    if (url.pathname.startsWith('/api/')) {
        return;
    }

    // 跳过非 GET 请求
    if (request.method !== 'GET') {
        return;
    }

    event.respondWith(
        caches.match(request).then((cachedResponse) => {
            if (cachedResponse) {
                // 返回缓存，同时后台更新
                const fetchPromise = fetch(request)
                    .then((networkResponse) => {
                        if (networkResponse.ok) {
                            const responseClone = networkResponse.clone();
                            caches.open(CACHE_NAME).then((cache) => {
                                cache.put(request, responseClone);
                            });
                        }
                        return networkResponse;
                    })
                    .catch(() => {});

                return cachedResponse;
            }

            // 没有缓存，从网络获取
            return fetch(request)
                .then((networkResponse) => {
                    if (networkResponse.ok) {
                        const responseClone = networkResponse.clone();
                        caches.open(CACHE_NAME).then((cache) => {
                            cache.put(request, responseClone);
                        });
                    }
                    return networkResponse;
                })
                .catch(() => {
                    // 网络失败且无缓存，返回离线页面
                    if (request.destination === 'document') {
                        return caches.match('/login.html');
                    }
                    return new Response('Offline', { status: 503 });
                });
        })
    );
});
