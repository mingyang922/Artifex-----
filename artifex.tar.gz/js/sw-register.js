/**
 * Artifex - Service Worker 注册
 * 在生产环境注册 Service Worker
 */
'use strict';

if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
    window.addEventListener('load', () => {
        navigator.serviceWorker
            .register('/sw.js')
            .then((registration) => {
                console.debug('[SW] 注册成功:', registration.scope);
            })
            .catch((error) => {
                console.debug('[SW] 注册失败:', error);
            });
    });
}
